# 📁 Drop Files Here!

## Step 1: Drop files in "1_Input"
That's it! Everything else is automatic.

## What's Happening?
📥 Files go to 1_Input/
↓
⚙️ System processes them
↓
📤 Find them in 3_Complete/

## Track Progress
Open "Pipeline" sheet to see:
- What's processing
- What's done
- Any issues

## Need Help?
Check your email - we'll notify you if anything needs attention.

---
*No setup needed. No servers to manage. Just drop and go!*
