# Welcome to EvidenceAI! 👋

## Just Drop Your Files Here
1. Drop files in the "1_Input" folder
2. We'll handle the rest automatically!

## Where to Find Things
📥 **New Files:** Drop in "1_Input" folder
📊 **Progress:** Check "Pipeline" sheet
📤 **Finished Files:** Look in "3_Complete" folder

## That's It!
No setup needed. No training required.
Just drop your files and we'll take care of everything.

Need help? Check your email - we'll let you know if anything needs attention.
